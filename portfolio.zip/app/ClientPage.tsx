"use client"

import Link from "next/link"
import Image from "next/image"
import { ArrowRight, Github, Linkedin, Code, BookOpen, Award, Briefcase, Mail } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"

export default function ClientPage() {
  return (
    <div className="flex min-h-screen flex-col">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="font-bold text-xl">
            <Link href="/">Pooja Reddy</Link>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex gap-6">
            <a href="#about" className="text-muted-foreground hover:text-foreground transition-colors">
              About
            </a>
            <a href="#education" className="text-muted-foreground hover:text-foreground transition-colors">
              Education
            </a>
            <a href="#experience" className="text-muted-foreground hover:text-foreground transition-colors">
              Experience
            </a>
            <a href="#skills" className="text-muted-foreground hover:text-foreground transition-colors">
              Skills
            </a>
            <a href="#projects" className="text-muted-foreground hover:text-foreground transition-colors">
              Projects
            </a>
            <a href="#achievements" className="text-muted-foreground hover:text-foreground transition-colors">
              Achievements
            </a>
          </nav>

          {/* Mobile Menu Button and Navigation */}
          <div className="md:hidden">
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              aria-label="Toggle menu"
              onClick={() => {
                const mobileMenu = document.getElementById("mobile-menu")
                if (mobileMenu) {
                  mobileMenu.classList.toggle("hidden")
                }
              }}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-6 w-6"
              >
                <line x1="4" x2="20" y1="12" y2="12" />
                <line x1="4" x2="20" y1="6" y2="6" />
                <line x1="4" x2="20" y1="18" y2="18" />
              </svg>
            </Button>
          </div>

          {/* Mobile Menu Dropdown */}
          <div id="mobile-menu" className="hidden md:hidden w-full bg-background border-b">
            <nav className="container py-4 flex flex-col space-y-4">
              <a
                href="#about"
                className="text-foreground hover:text-primary transition-colors py-2"
                onClick={() => {
                  document.getElementById("mobile-menu").classList.add("hidden")
                }}
              >
                About
              </a>
              <a
                href="#education"
                className="text-foreground hover:text-primary transition-colors py-2"
                onClick={() => {
                  document.getElementById("mobile-menu").classList.add("hidden")
                }}
              >
                Education
              </a>
              <a
                href="#experience"
                className="text-foreground hover:text-primary transition-colors py-2"
                onClick={() => {
                  document.getElementById("mobile-menu").classList.add("hidden")
                }}
              >
                Experience
              </a>
              <a
                href="#skills"
                className="text-foreground hover:text-primary transition-colors py-2"
                onClick={() => {
                  document.getElementById("mobile-menu").classList.add("hidden")
                }}
              >
                Skills
              </a>
              <a
                href="#projects"
                className="text-foreground hover:text-primary transition-colors py-2"
                onClick={() => {
                  document.getElementById("mobile-menu").classList.add("hidden")
                }}
              >
                Projects
              </a>
              <a
                href="#achievements"
                className="text-foreground hover:text-primary transition-colors py-2"
                onClick={() => {
                  document.getElementById("mobile-menu").classList.add("hidden")
                }}
              >
                Achievements
              </a>
            </nav>
          </div>

          <div className="hidden md:flex gap-4">
            <Link href="https://github.com/rontalapoojareddy" target="_blank" rel="noopener noreferrer">
              <Button size="icon" variant="ghost">
                <Github className="h-5 w-5" />
                <span className="sr-only">GitHub</span>
              </Button>
            </Link>
            <Link href="https://www.linkedin.com/in/r-pooja-reddy-9b70a1253/" target="_blank" rel="noopener noreferrer">
              <Button size="icon" variant="ghost">
                <Linkedin className="h-5 w-5" />
                <span className="sr-only">LinkedIn</span>
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section with enhanced styling */}
        <section className="w-full py-12 md:py-24 bg-gradient-to-b from-primary/5 to-background">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_500px]">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <Badge className="inline-block" variant="secondary">
                    Available for hire
                  </Badge>
                  <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">
                    Hi, I'm <span className="text-primary">Pooja Reddy Rontala</span>
                  </h1>
                  <p className="max-w-[600px] text-muted-foreground md:text-xl">
                    Computer Science Engineering student with a passion for technology, data analysis, and creating
                    impactful solutions.
                  </p>
                  <div className="flex flex-col space-y-2 text-muted-foreground">
                    <p>Hanamkonda (Telangana), India</p>
                    <p>
                      <a href="mailto:rontalapoojareddy@gmail.com" className="text-primary hover:underline">
                        rontalapoojareddy@gmail.com
                      </a>
                    </p>
                  </div>
                </div>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <a href="#projects">
                    <Button className="bg-primary hover:bg-primary/90">
                      View My Work <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </a>
                  <Link
                    href="https://drive.google.com/file/d/17uJwIfwc6YUQYYpU-oR5dZLSEou4DcV9/view?usp=drive_link"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <Button variant="outline">Download Resume</Button>
                  </Link>
                </div>
                <div className="flex gap-4">
                  <Link href="https://github.com/rontalapoojareddy" target="_blank" rel="noopener noreferrer">
                    <Button size="icon" variant="ghost">
                      <Github className="h-5 w-5" />
                      <span className="sr-only">GitHub</span>
                    </Button>
                  </Link>
                  <Link
                    href="https://www.linkedin.com/in/r-pooja-reddy-9b70a1253/"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <Button size="icon" variant="ghost">
                      <Linkedin className="h-5 w-5" />
                      <span className="sr-only">LinkedIn</span>
                    </Button>
                  </Link>
                  <Link
                    href="https://www.hackerrank.com/profile/rontalapoojared1"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <Button size="icon" variant="ghost">
                      <Code className="h-5 w-5" />
                      <span className="sr-only">HackerRank</span>
                    </Button>
                  </Link>
                  <Link href="https://leetcode.com/u/rontalapoojareddy/" target="_blank" rel="noopener noreferrer">
                    <Button size="icon" variant="ghost">
                      <BookOpen className="h-5 w-5" />
                      <span className="sr-only">LeetCode</span>
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="flex items-center justify-center">
                <div className="relative">
                  <div className="absolute -inset-1 rounded-full bg-gradient-to-r from-primary to-primary/50 opacity-75 blur-sm"></div>
                  <Image
                    alt="Pooja Reddy Rontala"
                    className="relative aspect-square overflow-hidden rounded-full object-cover border-4 border-background"
                    height="400"
                    width="400"
                    src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/pooja%20professional%20photo-gCnaKyIZfrSgrZh71ySRz6GtDgYmnO.jpeg"
                  />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Professional Summary Section with clickable items */}
        <section className="w-full py-12 bg-muted/30">
          <div className="container px-4 md:px-6">
            <div className="mx-auto max-w-3xl text-center">
              <h2 className="text-3xl font-bold tracking-tighter mb-6">Professional Summary</h2>
              <p className="text-lg text-muted-foreground mb-8">
                I'm a dedicated Computer Science Engineering student with a strong academic record (CGPA: 9.35/10) and
                practical experience through multiple internships. I'm passionate about leveraging technology to solve
                real-world problems, with particular interests in data analysis, web development, and cybersecurity.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
                <a href="#education" className="group">
                  <div className="flex flex-col items-center p-4 rounded-lg transition-all duration-300 hover:bg-primary/10">
                    <div className="rounded-full bg-primary/10 p-3 mb-4 group-hover:bg-primary/20">
                      <Award className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-medium mb-2 group-hover:text-primary">Academic Excellence</h3>
                    <p className="text-muted-foreground">Strong foundation in computer science with a 9.35/10 CGPA</p>
                  </div>
                </a>
                <a href="#experience" className="group">
                  <div className="flex flex-col items-center p-4 rounded-lg transition-all duration-300 hover:bg-primary/10">
                    <div className="rounded-full bg-primary/10 p-3 mb-4 group-hover:bg-primary/20">
                      <Briefcase className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-medium mb-2 group-hover:text-primary">Practical Experience</h3>
                    <p className="text-muted-foreground">Multiple internships in data science and web development</p>
                  </div>
                </a>
                <a href="#skills" className="group">
                  <div className="flex flex-col items-center p-4 rounded-lg transition-all duration-300 hover:bg-primary/10">
                    <div className="rounded-full bg-primary/10 p-3 mb-4 group-hover:bg-primary/20">
                      <Code className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-medium mb-2 group-hover:text-primary">Technical Skills</h3>
                    <p className="text-muted-foreground">Proficient in various programming languages and tools</p>
                  </div>
                </a>
              </div>
            </div>
          </div>
        </section>

        {/* About Section */}
        <section id="about" className="w-full py-12 md:py-24 lg:py-32 bg-muted/40">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">About Me</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  I'm a Computer Science Engineering student with a strong academic background and practical experience
                  through multiple internships. I'm passionate about data analysis, web development, and solving complex
                  problems.
                </p>
              </div>
            </div>
            <div className="mx-auto max-w-3xl mt-8">
              <div className="space-y-6">
                <div>
                  <h3 className="text-2xl font-bold mb-2">My Journey</h3>
                  <p className="text-muted-foreground">
                    I am currently pursuing my Bachelor's degree in Computer Science and Engineering at SR University,
                    where I've maintained a strong academic record with a CGPA of 9.35/10. Throughout my academic
                    journey, I've developed a keen interest in data analysis, web development, and software engineering.
                  </p>
                </div>

                <div>
                  <h3 className="text-2xl font-bold mb-2">My Interests</h3>
                  <p className="text-muted-foreground">
                    I'm particularly interested in leveraging technology to solve real-world problems. My experience
                    with data analysis tools like Power BI has allowed me to work on projects that extract meaningful
                    insights from complex datasets. I'm also passionate about web development and have created several
                    projects using HTML, CSS, and JavaScript.
                  </p>
                </div>

                <div>
                  <h3 className="text-2xl font-bold mb-2">My Goals</h3>
                  <p className="text-muted-foreground">
                    As I continue my education and career, I aim to further develop my technical skills and contribute
                    to innovative projects. I'm eager to collaborate with like-minded professionals and organizations
                    that value creativity, problem-solving, and continuous learning.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Education Section */}
        <section id="education" className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Education</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  My academic journey and qualifications
                </p>
              </div>
            </div>
            <div className="mx-auto max-w-3xl mt-8">
              <Card>
                <CardContent className="p-6">
                  <div className="flex flex-col space-y-2">
                    <h3 className="text-2xl font-bold">SR University</h3>
                    <p className="text-lg">Bachelor of Technology in Computer Science and Engineering</p>
                    <p className="text-primary font-semibold">Current CGPA: 9.35/10</p>
                    <div className="mt-4">
                      <h4 className="text-lg font-semibold mb-2">Key Coursework:</h4>
                      <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
                        <li>Data Structures and Algorithms</li>
                        <li>Database Management Systems</li>
                        <li>Operating Systems</li>
                        <li>Computer Networks</li>
                        <li>Web Technologies</li>
                        <li>Software Engineering</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Experience Section */}
        <section id="experience" className="w-full py-12 md:py-24 lg:py-32 bg-muted/40">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                  Internships & Work Experience
                </h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  My professional journey and practical experience
                </p>
              </div>
            </div>
            <div className="mx-auto max-w-4xl mt-8 space-y-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row justify-between">
                    <h3 className="text-xl font-bold">
                      <a
                        href="https://drive.google.com/file/d/1vlcDyOfX91kmk276vV321B_7jo721bbC/view?usp=sharing"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="hover:text-primary hover:underline"
                      >
                        UP Skill - Data Science
                      </a>
                    </h3>
                    <p className="text-muted-foreground">Mar 2024 - Apr 2024</p>
                  </div>
                  <p className="mt-4 text-muted-foreground">
                    Gained hands-on experience with data analysis techniques and tools. Worked on real-world datasets to
                    extract meaningful insights and create visualizations.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row justify-between">
                    <h3 className="text-xl font-bold">
                      <a
                        href="https://drive.google.com/file/d/1x8hW3Xbjd-b8qNa1g_sTiZ2AfZH5duMX/view?usp=sharing"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="hover:text-primary hover:underline"
                      >
                        EY GDS - AICTE Power BI Analysis of Indian Agriculture
                      </a>
                    </h3>
                    <p className="text-muted-foreground">Feb 2024 - April 2024</p>
                  </div>
                  <p className="mt-4 text-muted-foreground">
                    Analyzed agricultural data using Power BI to identify trends and patterns. Created interactive
                    dashboards to visualize key metrics and insights.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row justify-between">
                    <h3 className="text-xl font-bold">
                      <a
                        href="https://drive.google.com/file/d/1qfaw3jTkkdPRiwgp1qbs09-VMKbxhkPs/view?usp=sharing"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="hover:text-primary hover:underline"
                      >
                        Bharat Intern – Web Development
                      </a>
                    </h3>
                    <p className="text-muted-foreground">July 2023 - Aug 2023</p>
                  </div>
                  <p className="mt-4 text-muted-foreground">
                    Developed responsive web applications using HTML, CSS, and JavaScript. Collaborated with team
                    members to implement user-friendly interfaces and functionality.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row justify-between">
                    <h3 className="text-xl font-bold">
                      <a
                        href="https://drive.google.com/file/d/18lgSviMvVVxv6xvD-1qSPKU1syikEfJ6/view?usp=sharing"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="hover:text-primary hover:underline"
                      >
                        AICTE - AI ML Virtual Internship
                      </a>
                    </h3>
                    <p className="text-muted-foreground">May 2023 - July 2023</p>
                  </div>
                  <p className="mt-4 text-muted-foreground">
                    Participated in a virtual internship focused on artificial intelligence and machine learning
                    concepts. Completed projects and assignments related to data analysis and predictive modeling.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Skills Section */}
        <section id="skills" className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Technical Skills</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  My technical expertise and competencies
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl gap-6 py-12 md:grid-cols-2 lg:grid-cols-3">
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold">Programming</h3>
                  <ul className="mt-4 space-y-2">
                    <li className="flex items-center">
                      <div className="mr-2 h-2 w-2 rounded-full bg-primary"></div>
                      <span>C</span>
                    </li>
                    <li className="flex items-center">
                      <div className="mr-2 h-2 w-2 rounded-full bg-primary"></div>
                      <span>Python</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold">Web Technologies</h3>
                  <ul className="mt-4 space-y-2">
                    <li className="flex items-center">
                      <div className="mr-2 h-2 w-2 rounded-full bg-primary"></div>
                      <span>HTML</span>
                    </li>
                    <li className="flex items-center">
                      <div className="mr-2 h-2 w-2 rounded-full bg-primary"></div>
                      <span>CSS</span>
                    </li>
                    <li className="flex items-center">
                      <div className="mr-2 h-2 w-2 rounded-full bg-primary"></div>
                      <span>JavaScript (Basics)</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold">Frameworks & Tools</h3>
                  <ul className="mt-4 space-y-2">
                    <li className="flex items-center">
                      <div className="mr-2 h-2 w-2 rounded-full bg-primary"></div>
                      <span>Power BI</span>
                    </li>
                    <li className="flex items-center">
                      <div className="mr-2 h-2 w-2 rounded-full bg-primary"></div>
                      <span>Bootstrap</span>
                    </li>
                    <li className="flex items-center">
                      <div className="mr-2 h-2 w-2 rounded-full bg-primary"></div>
                      <span>Visual Studio Code</span>
                    </li>
                    <li className="flex items-center">
                      <div className="mr-2 h-2 w-2 rounded-full bg-primary"></div>
                      <span>Thonny</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold">Database</h3>
                  <ul className="mt-4 space-y-2">
                    <li className="flex items-center">
                      <div className="mr-2 h-2 w-2 rounded-full bg-primary"></div>
                      <span>MySQL</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold">Coursework</h3>
                  <ul className="mt-4 space-y-2">
                    <li className="flex items-center">
                      <div className="mr-2 h-2 w-2 rounded-full bg-primary"></div>
                      <span>Data Structures and Algorithms</span>
                    </li>
                    <li className="flex items-center">
                      <div className="mr-2 h-2 w-2 rounded-full bg-primary"></div>
                      <span>Operating Systems</span>
                    </li>
                    <li className="flex items-center">
                      <div className="mr-2 h-2 w-2 rounded-full bg-primary"></div>
                      <span>Database Management Systems</span>
                    </li>
                    <li className="flex items-center">
                      <div className="mr-2 h-2 w-2 rounded-full bg-primary"></div>
                      <span>Computer Networks</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold">Other Skills</h3>
                  <ul className="mt-4 space-y-2">
                    <li className="flex items-center">
                      <div className="mr-2 h-2 w-2 rounded-full bg-primary"></div>
                      <span>Data Analysis</span>
                    </li>
                    <li className="flex items-center">
                      <div className="mr-2 h-2 w-2 rounded-full bg-primary"></div>
                      <span>Problem Solving</span>
                    </li>
                    <li className="flex items-center">
                      <div className="mr-2 h-2 w-2 rounded-full bg-primary"></div>
                      <span>GitHub</span>
                    </li>
                    <li className="flex items-center">
                      <div className="mr-2 h-2 w-2 rounded-full bg-primary"></div>
                      <span>Team Collaboration</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Projects Section */}
        <section id="projects" className="w-full py-12 md:py-24 lg:py-32 bg-muted/40">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Projects</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Here are some of the projects I've worked on that showcase my skills and interests.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl items-center gap-6 py-12 md:grid-cols-2 lg:grid-cols-3">
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold">
                    <a
                      href="https://github.com/rontalapoojareddy/MajorProject_Cybersecurity-Enhancement-through-Malicious-URL-Detection-with-ML"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="hover:text-primary hover:underline"
                    >
                      Cybersecurity Enhancement through Malicious URL Detection with ML
                    </a>
                  </h3>
                  <p className="text-muted-foreground mt-2">Machine learning approach to detect malicious URLs.</p>
                  <p className="mt-4 text-sm text-muted-foreground">
                    Developed a system that uses machine learning algorithms to identify potentially harmful URLs.
                    Implemented feature extraction techniques and trained models to classify URLs as malicious or
                    benign.
                  </p>
                  <div className="mt-4 flex flex-wrap gap-2">
                    <Badge>Python</Badge>
                    <Badge>Machine Learning</Badge>
                    <Badge>Cybersecurity</Badge>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold">
                    <a
                      href="https://github.com/rontalapoojareddy/Passenger-reservation-Syestem"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="hover:text-primary hover:underline"
                    >
                      Passengers Reservation System
                    </a>
                  </h3>
                  <p className="text-muted-foreground mt-2">A reservation system built using C language.</p>
                  <p className="mt-4 text-sm text-muted-foreground">
                    Implemented a console-based reservation system with features for booking, cancellation, and viewing
                    available seats. Used efficient algorithms for data management and user-friendly interfaces.
                  </p>
                  <div className="mt-4 flex flex-wrap gap-2">
                    <Badge>C</Badge>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold">
                    <a
                      href="https://github.com/rontalapoojareddy/Capstone-Smart-Travel-Planner"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="hover:text-primary hover:underline"
                    >
                      Smart Travel Planner
                    </a>
                  </h3>
                  <p className="text-muted-foreground mt-2">A travel planning application with itinerary management.</p>
                  <p className="mt-4 text-sm text-muted-foreground">
                    Developed a travel planning application that helps users create and manage travel itineraries.
                    Features include destination search, budget tracking, and schedule optimization.
                  </p>
                  <div className="mt-4 flex flex-wrap gap-2">
                    <Badge>HTML</Badge>
                    <Badge>CSS</Badge>
                    <Badge>JavaScript</Badge>
                    <Badge>Responsive Design</Badge>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold">
                    <a
                      href="https://github.com/rontalapoojareddy/Bharat-Intern-Netflix-home-page"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="hover:text-primary hover:underline"
                    >
                      Netflix Home Page Clone
                    </a>
                  </h3>
                  <p className="text-muted-foreground mt-2">A recreation of the Netflix homepage using HTML and CSS.</p>
                  <p className="mt-4 text-sm text-muted-foreground">
                    Created a responsive clone of the Netflix homepage with attention to detail in layout, styling, and
                    interactive elements. Implemented responsive design principles for optimal viewing on different
                    devices.
                  </p>
                  <div className="mt-4 flex flex-wrap gap-2">
                    <Badge>HTML</Badge>
                    <Badge>CSS</Badge>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold">Portfolio Website</h3>
                  <p className="text-muted-foreground mt-2">Personal portfolio website built with HTML and CSS.</p>
                  <p className="mt-4 text-sm text-muted-foreground">
                    Designed and developed a personal portfolio website to showcase skills, projects, and achievements.
                    Implemented responsive design and modern UI/UX principles.
                  </p>
                  <div className="mt-4 flex flex-wrap gap-2">
                    <Badge>HTML</Badge>
                    <Badge>CSS</Badge>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold">
                    <a
                      href="https://github.com/rontalapoojareddy/Bharat-Intern-temperature-converter"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="hover:text-primary hover:underline"
                    >
                      Temperature Converter
                    </a>
                  </h3>
                  <p className="text-muted-foreground mt-2">A tool to convert between temperature units.</p>
                  <p className="mt-4 text-sm text-muted-foreground">
                    Developed a web-based temperature converter that allows users to convert between Celsius,
                    Fahrenheit, and Kelvin. Implemented input validation and real-time conversion.
                  </p>
                  <div className="mt-4 flex flex-wrap gap-2">
                    <Badge>HTML</Badge>
                    <Badge>CSS</Badge>
                    <Badge>JavaScript</Badge>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Achievements Section */}
        <section id="achievements" className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Additional Achievements</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Certifications, awards, and other accomplishments
                </p>
              </div>
            </div>
            <div className="mx-auto max-w-4xl mt-8 space-y-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <Award className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="text-xl font-bold">
                        <a
                          href="https://drive.google.com/file/d/1bwguKL_IVyy5mgq767vUkH7xnBhXaBM5/view?usp=sharing"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="hover:text-primary hover:underline"
                        >
                          Coursera: Digital Marketing Strategy and Planning
                        </a>
                      </h3>
                      <p className="text-muted-foreground">March 2024</p>
                      <p className="mt-2 text-muted-foreground">
                        Completed a comprehensive course on digital marketing strategies and planning techniques.
                        Learned about market analysis, campaign development, and performance measurement.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <Award className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="text-xl font-bold">
                        <a
                          href="https://drive.google.com/file/d/1rDreRis5OUroU0GhSpzxsxpqsuIQy3xZ/view?usp=sharing"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="hover:text-primary hover:underline"
                        >
                          Edx: Automated Software Testing by DelftX
                        </a>
                      </h3>
                      <p className="mt-2 text-muted-foreground">
                        Completed a course on automated software testing techniques and best practices. Learned about
                        test case design, test automation frameworks, and continuous integration.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <Award className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="text-xl font-bold">
                        <a
                          href="https://drive.google.com/file/d/187mQtLDJ0tHWttGyzsI9iMW0GgI2T7qB/view?usp=sharing"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="hover:text-primary hover:underline"
                        >
                          NPTEL: Database Management System
                        </a>
                      </h3>
                      <p className="text-muted-foreground">September 2023</p>
                      <p className="mt-2 text-muted-foreground">
                        Completed a comprehensive course on database management systems. Learned about database design,
                        SQL, normalization, and transaction management.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <Award className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="text-xl font-bold">
                        <a
                          href="https://drive.google.com/file/d/1lxox1EQ6O7X1sz4ub6bK2bnGw2goE-JN/view?usp=sharing"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="hover:text-primary hover:underline"
                        >
                          Introduction to Cryptography and Network Security
                        </a>
                      </h3>
                      <p className="text-muted-foreground">November 2023</p>
                      <p className="mt-2 text-muted-foreground">
                        Completed a course on cryptography fundamentals and network security principles. Learned about
                        encryption algorithms, security protocols, and cybersecurity best practices.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <Code className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="text-xl font-bold">
                        <a
                          href="https://drive.google.com/file/d/1nq90nY4MnHzisvHu5vIt_TAfJH8YnOXu/view?usp=sharing"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="hover:text-primary hover:underline"
                        >
                          CodeQuest 41 Days Coding Challenge
                        </a>
                      </h3>
                      <p className="text-muted-foreground">
                        Organized by SR University coding club on HackerRank platform
                      </p>
                      <p className="mt-2 text-muted-foreground">
                        Participated in a 41-day coding challenge, solving daily programming problems and algorithms.
                        Improved problem-solving skills and algorithmic thinking.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <Code className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="text-xl font-bold">
                        <a
                          href="https://drive.google.com/file/d/1ckusFMUmVxW1JzH9wO3P89BnMsu1IvZC/view?usp=sharing"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="hover:text-primary hover:underline"
                        >
                          Hackathon Participation
                        </a>
                      </h3>
                      <p className="text-muted-foreground">
                        Participated in "Hackathon" and "PROGRAMMING HACKATHON" organized by Dept. of Computer Science
                        and Artificial Intelligence, SR University
                      </p>
                      <p className="mt-2 text-muted-foreground">
                        Collaborated with team members to develop innovative solutions to real-world problems within a
                        limited timeframe. Enhanced teamwork, problem-solving, and coding skills.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <Code className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="text-xl font-bold">
                        <a
                          href="https://drive.google.com/file/d/1lDwNF6Utpf18iUMg7e58myoM4VgNui4r/view?usp=sharing"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="hover:text-primary hover:underline"
                        >
                          Night Hackathon Participation
                        </a>
                      </h3>
                      <p className="text-muted-foreground">
                        Participated in the Night Hackathon organized by SR University
                      </p>
                      <p className="mt-2 text-muted-foreground">
                        Worked through the night with a team to develop and present a technology solution under tight
                        time constraints. Demonstrated perseverance, creativity, and technical skills.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Call to Action Section */}
        <section className="w-full py-12 md:py-24 bg-primary/5">
          <div className="container px-4 md:px-6">
            <div className="mx-auto max-w-3xl text-center">
              <h2 className="text-3xl font-bold tracking-tighter mb-4">Ready to Collaborate?</h2>
              <p className="text-lg text-muted-foreground mb-8">
                I'm currently seeking opportunities to apply my skills and knowledge in a professional environment.
                Whether you're looking for a dedicated team member or have a project in mind, I'd love to connect.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <a href="mailto:rontalapoojareddy@gmail.com">
                  <Button className="w-full sm:w-auto">
                    <Mail className="mr-2 h-4 w-4" /> Email Me
                  </Button>
                </a>
                <Link
                  href="https://drive.google.com/file/d/17uJwIfwc6YUQYYpU-oR5dZLSEou4DcV9/view?usp=drive_link"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Button variant="outline" className="w-full sm:w-auto">
                    Download Resume
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="w-full border-t py-6 md:py-0">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-16 md:flex-row">
          <p className="text-center text-sm leading-loose text-muted-foreground md:text-left">
            © {new Date().getFullYear()} Pooja Reddy Rontala. All rights reserved.
          </p>
          <div className="flex gap-4">
            <Link href="https://github.com/rontalapoojareddy" target="_blank" rel="noopener noreferrer">
              <Button size="icon" variant="ghost">
                <Github className="h-4 w-4" />
                <span className="sr-only">GitHub</span>
              </Button>
            </Link>
            <Link href="https://www.linkedin.com/in/r-pooja-reddy-9b70a1253/" target="_blank" rel="noopener noreferrer">
              <Button size="icon" variant="ghost">
                <Linkedin className="h-4 w-4" />
                <span className="sr-only">LinkedIn</span>
              </Button>
            </Link>
            <Link href="https://www.hackerrank.com/profile/rontalapoojared1" target="_blank" rel="noopener noreferrer">
              <Button size="icon" variant="ghost">
                <Code className="h-4 w-4" />
                <span className="sr-only">HackerRank</span>
              </Button>
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
