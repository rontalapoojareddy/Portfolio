import type React from "react"
import type { Metadata } from "next"
import Link from "next/link"
import Image from "next/image"
import {
  ArrowRight,
  Github,
  Linkedin,
  Code,
  BookOpen,
  Award,
  Briefcase,
  Mail,
  Database,
  Globe,
  BarChart,
  Cpu,
  ExternalLink,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { MobileMenu } from "@/components/mobile-menu"
import { ThemeToggle } from "@/components/theme-toggle"

export const metadata: Metadata = {
  title: "Pooja Reddy Rontala - Portfolio",
  description: "Professional portfolio of Pooja Reddy Rontala showcasing skills, projects, and achievements.",
}

// Project type
interface Project {
  title: string
  description: string
  link: string
  tags: string[]
}

// Achievement type
interface Achievement {
  title: string
  description: string
  link: string
  date?: string
  type: "certification" | "award" | "challenge"
  organization?: string
}

// Skill category type
interface SkillCategory {
  title: string
  icon: React.ReactNode
  skills: string[]
}

// Projects data
const projects: Project[] = [
  {
    title: "Malicious URL Detection using Machine Learning",
    description:
      "Engineered a system leveraging machine learning algorithms to identify potentially harmful URLs with 92% accuracy. Implemented feature extraction techniques and trained classification models to distinguish between malicious and benign web addresses.",
    link: "https://github.com/rontalapoojareddy/MajorProject_Cybersecurity-Enhancement-through-Malicious-URL-Detection-with-ML",
    tags: ["Python", "Machine Learning", "Cybersecurity"],
  },
  {
    title: "Passenger Reservation System",
    description:
      "Developed a console-based reservation system using C structures to manage passenger data and bookings. Implemented efficient algorithms for data management and intuitive user interfaces, reducing booking time by 40%.",
    link: "https://github.com/rontalapoojareddy/Passenger-reservation-Syestem",
    tags: ["C"],
  },
  {
    title: "Smart Travel Planner",
    description:
      "Architected a full-stack travel planning application using Python and MySQL that facilitates the creation and management of travel itineraries. Incorporated features for destination research, budget tracking, and itinerary optimization.",
    link: "https://github.com/rontalapoojareddy/Capstone-Smart-Travel-Planner",
    tags: ["Python", "MySQL", "Full-Stack"],
  },
  {
    title: "Netflix Home Page Replica",
    description:
      "Crafted a responsive replica of the Netflix homepage with meticulous attention to layout architecture and styling elements. Implemented responsive design principles to ensure optimal viewing experiences across various devices.",
    link: "https://github.com/rontalapoojareddy/Bharat-Intern-Netflix-home-page",
    tags: ["HTML", "CSS"],
  },
  {
    title: "Temperature Converter",
    description:
      "Constructed a web-based temperature conversion utility using JavaScript that enables seamless conversion between Celsius, Fahrenheit, and Kelvin scales. Implemented robust input validation and real-time conversion functionality.",
    link: "https://github.com/rontalapoojareddy/Bharat-Intern-temperature-converter",
    tags: ["HTML", "CSS", "JavaScript"],
  },
  {
    title: "Responsive Blog",
    description:
      "Designed a comprehensive blog layout with mobile-first responsiveness, ensuring optimal viewing experience across all device sizes. Implemented modern CSS techniques for responsive design and accessibility.",
    link: "https://github.com/rontalapoojareddy/Blogs",
    tags: ["HTML", "CSS", "Responsive Design"],
  },
  {
    title: "Decorative Items Website",
    description:
      "Developed a product showcase website for decorative items using HTML and CSS. Created an aesthetically pleasing interface to highlight product features and details, improving user engagement metrics.",
    link: "https://github.com/rontalapoojareddy/Decorative",
    tags: ["HTML", "CSS", "Web Design"],
  },
  {
    title: "Website Redesign using Figma",
    description:
      "Enhanced user interface and experience of an existing website through comprehensive redesign using Figma. Created wireframes, prototypes, and final designs to improve usability and visual appeal.",
    link: "https://github.com/rontalapoojareddy/Figma-design",
    tags: ["Figma", "UI/UX", "Design"],
  },
  {
    title: "Agriculture Data Analysis using Power BI",
    description:
      "Visualized trends in Indian agriculture using Power BI, creating interactive dashboards to present insights on crop production patterns across years. Implemented data transformation and visualization techniques to identify key growth areas.",
    link: "https://github.com/rontalapoojareddy/PowerBi",
    tags: ["Power BI", "Data Analysis", "Visualization"],
  },
]

// Achievements data
const achievements: Achievement[] = [
  {
    title: "Coursera: Digital Marketing Strategy and Planning",
    description:
      "Completed a comprehensive course on digital marketing methodologies and planning techniques. Acquired expertise in market analysis, campaign development strategies, and performance measurement frameworks.",
    link: "https://drive.google.com/file/d/1bwguKL_IVyy5mgq767vUkH7xnBhXaBM5/view?usp=sharing",
    date: "March 2024",
    type: "certification",
    organization: "Coursera",
  },
  {
    title: "EdX: Automated Software Testing by DelftX",
    description:
      "Mastered concepts in automated software testing methodologies and industry best practices. Gained proficiency in test case design principles, automation framework implementation, and continuous integration processes.",
    link: "https://drive.google.com/file/d/1rDreRis5OUroU0GhSpzxsxpqsuIQy3xZ/view?usp=sharing",
    date: "February 2024",
    type: "certification",
    organization: "EdX",
  },
  {
    title: "EdX: Introduction to Encryption and Cryptography",
    description:
      "Completed a course on encryption fundamentals and cryptographic techniques. Gained knowledge of security protocols and encryption algorithms essential for secure data transmission.",
    link: "https://drive.google.com/file/d/1Bg2q79cAbFxFS-941zLXdbZWo2f-srBG/view",
    date: "September 2023",
    type: "certification",
    organization: "EdX",
  },
  {
    title: "NPTEL: Database Management System",
    description:
      "Acquired knowledge of database management systems, including relational database design, SQL query optimization, normalization techniques, and transaction management principles.",
    link: "https://drive.google.com/file/d/187mQtLDJ0tHWttGyzsI9iMW0GgI2T7qB/view?usp=sharing",
    date: "September 2023",
    type: "certification",
    organization: "NPTEL",
  },
  {
    title: "Saylor: Introduction to Cryptography and Network Security",
    description:
      "Completed a course on cryptography fundamentals and network security principles. Studied encryption methods, security protocols, and cybersecurity best practices.",
    link: "https://drive.google.com/file/d/1lxox1EQ6O7X1sz4ub6bK2bnGw2goE-JN/view?usp=sharing",
    date: "March 2025",
    type: "certification",
    organization: "Saylor",
  },
  {
    title: "CodeQuest 41 Days Coding Challenge",
    description:
      "Participated in an intensive 41-day coding challenge on HackerRank, solving complex programming problems and implementing efficient algorithms. Enhanced problem-solving capabilities and algorithmic thinking skills.",
    link: "https://drive.google.com/file/d/1nq90nY4MnHzisvHu5vIt_TAfJH8YnOXu/view?usp=sharing",
    type: "challenge",
    organization: "SR University coding club",
  },
  {
    title: "Hackathon Participation",
    description:
      "Collaborated with cross-functional team members to develop innovative solutions addressing real-world challenges within stringent time constraints. Demonstrated teamwork, problem-solving abilities, and technical implementation skills.",
    link: "https://drive.google.com/file/d/1ckusFMUmVxW1JzH9wO3P89BnMsu1IvZC/view?usp=sharing",
    type: "challenge",
    organization: "Dept. of CSE and AI, SR University",
  },
  {
    title: "Programming Hackathon (Night Technical Event)",
    description:
      "Participated in an overnight technical hackathon, developing solutions under tight deadlines. Demonstrated technical prowess, teamwork, and resilience during extended problem-solving sessions.",
    link: "https://drive.google.com/file/d/1lDwNF6Utpf18iUMg7e58myoM4VgNui4r/view?usp=sharing",
    type: "challenge",
    organization: "SR University",
  },
  {
    title: "HackerRank: CSS Basics",
    description:
      "Completed certification demonstrating proficiency in CSS fundamentals, including selectors, layout techniques, and responsive design principles.",
    link: "https://drive.google.com/file/d/1lT6eG-DWePmROcg7BaIcNNajAptjbYiv/view",
    type: "certification",
    organization: "HackerRank",
  },
  {
    title: "Great Learning: ChatGPT for Beginners",
    description:
      "Completed a course on leveraging ChatGPT for various applications. Learned prompt engineering techniques and practical applications of AI in everyday tasks and professional settings.",
    link: "https://drive.google.com/file/d/1gFkwXyOl5NkhezIstOh9ncC7F-hpjiz4/view",
    type: "certification",
    organization: "Great Learning",
  },
]

// Skill categories
const skillCategories: SkillCategory[] = [
  {
    title: "Programming Languages",
    icon: <Code className="h-6 w-6 text-primary" />,
    skills: ["Python", "C", "Java (Basics)"],
  },
  {
    title: "Web Technologies",
    icon: <Globe className="h-6 w-6 text-primary" />,
    skills: ["HTML", "CSS", "JavaScript (Basics)", "Bootstrap"],
  },
  {
    title: "Frameworks & Tools",
    icon: <Cpu className="h-6 w-6 text-primary" />,
    skills: ["Power BI", "Bootstrap", "DevC++", "VS Code", "Thonny"],
  },
  {
    title: "Database",
    icon: <Database className="h-6 w-6 text-primary" />,
    skills: ["MySQL"],
  },
  {
    title: "Coursework",
    icon: <BookOpen className="h-6 w-6 text-primary" />,
    skills: ["Data Structures and Algorithms", "Operating Systems", "Database Management Systems", "Computer Networks"],
  },
  {
    title: "Professional Skills",
    icon: <BarChart className="h-6 w-6 text-primary" />,
    skills: [
      "Data Analysis",
      "Problem Solving",
      "Version Control (Git)",
      "Team Collaboration",
      "Research and Analysis",
      "Technical Documentation",
      "Presentation Skills",
    ],
  },
]

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="font-bold text-xl">
            <Link href="/" className="focus:outline-none focus:ring-2 focus:ring-primary rounded-md px-2 py-1">
              Pooja Reddy
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex gap-6">
            <a href="#about" className="text-muted-foreground hover:text-foreground transition-colors">
              About
            </a>
            <a href="#education" className="text-muted-foreground hover:text-foreground transition-colors">
              Education
            </a>
            <a href="#experience" className="text-muted-foreground hover:text-foreground transition-colors">
              Experience
            </a>
            <a href="#projects" className="text-muted-foreground hover:text-foreground transition-colors">
              Projects
            </a>
            <a href="#skills" className="text-muted-foreground hover:text-foreground transition-colors">
              Skills
            </a>
            <a href="#achievements" className="text-muted-foreground hover:text-foreground transition-colors">
              Achievements
            </a>
            <a href="#contact" className="text-muted-foreground hover:text-foreground transition-colors">
              Contact
            </a>
          </nav>

          {/* Mobile Menu */}
          <div className="md:hidden">
            <MobileMenu />
          </div>

          <div className="hidden md:flex items-center gap-4">
            <ThemeToggle />
            <Link href="https://github.com/rontalapoojareddy" target="_blank" rel="noopener noreferrer">
              <Button size="icon" variant="ghost">
                <Github className="h-5 w-5" />
                <span className="sr-only">GitHub</span>
              </Button>
            </Link>
            <Link href="https://www.linkedin.com/in/r-pooja-reddy-9b70a1253/" target="_blank" rel="noopener noreferrer">
              <Button size="icon" variant="ghost">
                <Linkedin className="h-5 w-5" />
                <span className="sr-only">LinkedIn</span>
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section with enhanced responsiveness */}
        <section className="w-full py-8 md:py-12 bg-gradient-to-b from-primary/5 to-background">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_500px]">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <Badge className="inline-block" variant="secondary">
                    Available for hire
                  </Badge>
                  <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl xl:text-6xl/none">
                    Hi, I'm <span className="text-primary">Pooja Reddy Rontala</span>
                  </h1>
                  <p className="max-w-[600px] text-muted-foreground md:text-xl">
                    Computer Science Engineering student specializing in data analytics, web development, and software
                    solutions.
                  </p>
                  <div className="flex flex-col space-y-2 text-muted-foreground">
                    <p>Hanamkonda (Telangana), India</p>
                    <div className="flex flex-col space-y-1">
                      <a
                        href="mailto:rontalapoojareddy@gmail.com"
                        className="text-primary hover:underline flex items-center touch-target"
                      >
                        <Mail className="h-4 w-4 mr-2" /> rontalapoojareddy@gmail.com
                      </a>
                    </div>
                  </div>
                </div>
                <div className="flex flex-col sm:flex-row gap-2">
                  <a href="#projects">
                    <Button className="bg-primary hover:bg-primary/90 w-full sm:w-auto">
                      View My Work <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </a>
                  <Link
                    href="https://drive.google.com/file/d/1Dy-4-AD1j07jP1LdZNlO1TH3OiNw8eIN/view?usp=sharing"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <Button variant="outline" className="w-full sm:w-auto">
                      Download Resume
                    </Button>
                  </Link>
                </div>
                <div className="flex gap-4 flex-wrap">
                  <Link href="https://github.com/rontalapoojareddy" target="_blank" rel="noopener noreferrer">
                    <Button size="icon" variant="ghost" className="touch-target">
                      <Github className="h-5 w-5" />
                      <span className="sr-only">GitHub</span>
                    </Button>
                  </Link>
                  <Link
                    href="https://www.linkedin.com/in/r-pooja-reddy-9b70a1253/"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <Button size="icon" variant="ghost" className="touch-target">
                      <Linkedin className="h-5 w-5" />
                      <span className="sr-only">LinkedIn</span>
                    </Button>
                  </Link>
                  <Link
                    href="https://www.hackerrank.com/profile/rontalapoojared1"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <Button size="icon" variant="ghost" className="touch-target">
                      <Code className="h-5 w-5" />
                      <span className="sr-only">HackerRank</span>
                    </Button>
                  </Link>
                  <Link href="https://leetcode.com/u/rontalapoojareddy/" target="_blank" rel="noopener noreferrer">
                    <Button size="icon" variant="ghost" className="touch-target">
                      <BookOpen className="h-5 w-5" />
                      <span className="sr-only">LeetCode</span>
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="flex items-center justify-center">
                <div className="relative w-full max-w-[300px] md:max-w-[400px]">
                  <div className="absolute -inset-1 rounded-full bg-gradient-to-r from-primary to-primary/50 opacity-75 blur-sm"></div>
                  <Image
                    alt="Pooja Reddy Rontala"
                    className="relative aspect-square overflow-hidden rounded-full object-cover border-4 border-background"
                    height="400"
                    width="400"
                    src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/pooja%20professional%20photo-gCnaKyIZfrSgrZh71ySRz6GtDgYmnO.jpeg"
                    priority
                    sizes="(max-width: 640px) 280px, (max-width: 768px) 300px, 400px"
                  />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Professional Summary Section */}
        <section className="w-full py-6 bg-muted/30">
          <div className="container px-4 md:px-6">
            <div className="mx-auto max-w-3xl text-center">
              <h2 className="text-3xl font-bold tracking-tighter mb-6">Professional Summary</h2>
              <p className="text-lg text-muted-foreground mb-8">
                Computer Science Engineering student with a 9.35/10 CGPA and practical experience through multiple
                internships. Focused on data analytics, web development, and cybersecurity with a proven track record of
                delivering high-quality solutions through academic projects and professional engagements.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
                <a href="#education" className="group">
                  <div className="flex flex-col items-center p-4 rounded-lg transition-all duration-300 hover:bg-primary/10">
                    <div className="rounded-full bg-primary/10 p-3 mb-4 group-hover:bg-primary/20">
                      <Award className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-medium mb-2 group-hover:text-primary">Academic Excellence</h3>
                    <p className="text-muted-foreground">CGPA: 9.35/10 with strong technical foundation</p>
                  </div>
                </a>
                <a href="#experience" className="group">
                  <div className="flex flex-col items-center p-4 rounded-lg transition-all duration-300 hover:bg-primary/10">
                    <div className="rounded-full bg-primary/10 p-3 mb-4 group-hover:bg-primary/20">
                      <Briefcase className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-medium mb-2 group-hover:text-primary">Industry Experience</h3>
                    <p className="text-muted-foreground">Internships in data science and web development</p>
                  </div>
                </a>
                <a href="#skills" className="group">
                  <div className="flex flex-col items-center p-4 rounded-lg transition-all duration-300 hover:bg-primary/10">
                    <div className="rounded-full bg-primary/10 p-3 mb-4 group-hover:bg-primary/20">
                      <Code className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-medium mb-2 group-hover:text-primary">Technical Proficiency</h3>
                    <p className="text-muted-foreground">Programming, web technologies, and data analysis</p>
                  </div>
                </a>
              </div>
            </div>
          </div>
        </section>

        {/* About Section */}
        <section id="about" className="w-full py-8 md:py-12 lg:py-16 bg-muted/40">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">About Me</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Computer Science Engineering student with a strong academic record and practical experience through
                  internships.
                </p>
              </div>
            </div>
            <div className="mx-auto max-w-3xl mt-8">
              <div className="space-y-6">
                <div>
                  <h3 className="text-2xl font-bold mb-2">Background</h3>
                  <p className="text-muted-foreground">
                    Currently pursuing a Bachelor's degree in Computer Science and Engineering at SR University with a
                    9.35/10 CGPA. My academic journey has equipped me with strong foundations in data structures,
                    algorithms, database management, and software engineering principles. I complement theoretical
                    knowledge with practical applications through internships and personal projects.
                  </p>
                </div>

                <div>
                  <h3 className="text-2xl font-bold mb-2">Professional Focus</h3>
                  <p className="text-muted-foreground">
                    My professional interests center on implementing technological solutions for real-world challenges.
                    I've developed expertise in data analysis using Power BI, creating interactive dashboards that
                    transform complex datasets into actionable insights. Additionally, I've built responsive web
                    applications and explored machine learning applications in cybersecurity.
                  </p>
                </div>

                <div>
                  <h3 className="text-2xl font-bold mb-2">Career Objectives</h3>
                  <p className="text-muted-foreground">
                    I aim to leverage my technical skills in a professional environment where I can contribute to
                    innovative solutions while continuing to expand my expertise. I'm particularly interested in
                    opportunities that involve data analytics, web development, or software engineering, where I can
                    apply my problem-solving abilities and technical knowledge to create impactful solutions.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Education Section */}
        <section id="education" className="w-full py-8 md:py-12 lg:py-16">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Education</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Academic qualifications and coursework
                </p>
              </div>
            </div>
            <div className="mx-auto max-w-3xl mt-8">
              <Card>
                <CardContent className="p-6">
                  <div className="flex flex-col space-y-2">
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
                      <h3 className="text-2xl font-bold">SR University</h3>
                      <p className="text-muted-foreground">2021 - 2025</p>
                    </div>
                    <p className="text-lg">Bachelor of Technology in Computer Science and Engineering</p>
                    <p className="text-primary font-semibold">
                      <a
                        href="https://drive.google.com/file/d/17nLdQVS2ca5fvkiqwjWPmPSFtwhMc6ze/view?usp=drive_link"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="hover:underline inline-flex items-center gap-1 py-1 px-0.5 focus:outline-none focus:ring-2 focus:ring-primary rounded-sm touch-manipulation"
                        aria-label="View CGPA certificate - Current CGPA: 9.35/10"
                      >
                        Current CGPA: 9.35/10 <ExternalLink className="h-3.5 w-3.5 inline" />
                      </a>
                    </p>
                    <div className="mt-4">
                      <h4 className="text-lg font-semibold mb-2">Key Coursework:</h4>
                      <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
                        <li>Data Structures and Algorithms</li>
                        <li>Database Management Systems</li>
                        <li>Operating Systems</li>
                        <li>Computer Networks</li>
                        <li>Web Technologies</li>
                        <li>Software Engineering</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Experience Section */}
        <section id="experience" className="w-full py-8 md:py-12 lg:py-16 bg-muted/40">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Professional Experience</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Internships and industry exposure
                </p>
              </div>
            </div>
            <div className="mx-auto max-w-4xl mt-8 space-y-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row justify-between">
                    <h3 className="text-xl font-bold">
                      <a
                        href="https://drive.google.com/file/d/1vlcDyOfX91kmk276vV321B_7jo721bbC/view?usp=sharing"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="hover:text-primary hover:underline"
                      >
                        UP Skill - Data Science Training
                      </a>
                    </h3>
                    <p className="text-muted-foreground">Mar 2024 - Apr 2024</p>
                  </div>
                  <p className="mt-4 text-muted-foreground">
                    Analyzed complex datasets and developed data visualization solutions. Applied statistical methods to
                    extract meaningful insights and created comprehensive reports highlighting key findings. Utilized
                    Python and data analysis libraries to process and interpret large datasets.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row justify-between">
                    <h3 className="text-xl font-bold">
                      <a
                        href="https://drive.google.com/file/d/1x8hW3Xbjd-b8qNa1g_sTiZ2AfZH5duMX/view?usp=sharing"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="hover:text-primary hover:underline"
                      >
                        EY GDS - Power BI Analysis of Indian Agriculture
                      </a>
                    </h3>
                    <p className="text-muted-foreground">Feb 2024 - April 2024</p>
                  </div>
                  <p className="mt-4 text-muted-foreground">
                    Created interactive dashboards visualizing agricultural data trends across India. Analyzed crop
                    production patterns, identified key growth areas, and presented actionable insights through data
                    visualization. Implemented data transformation techniques to enhance the clarity and impact of
                    analytical findings.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row justify-between">
                    <h3 className="text-xl font-bold">
                      <a
                        href="https://drive.google.com/file/d/1qfaw3jTkkdPRiwgp1qbs09-VMKbxhkPs/view?usp=sharing"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="hover:text-primary hover:underline"
                      >
                        Bharat Intern – Web Development
                      </a>
                    </h3>
                    <p className="text-muted-foreground">July 2023 - Aug 2023</p>
                  </div>
                  <p className="mt-4 text-muted-foreground">
                    Developed responsive web applications including a Temperature Converter and Netflix homepage
                    replica. Implemented modern front-end development practices, responsive design principles, and
                    user-friendly interfaces. Demonstrated attention to detail in UI implementation and cross-browser
                    compatibility.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row justify-between">
                    <h3 className="text-xl font-bold">
                      <a
                        href="https://drive.google.com/file/d/18lgSviMvVVxv6xvD-1qSPKU1syikEfJ6/view?usp=sharing"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="hover:text-primary hover:underline"
                      >
                        AICTE - AI ML Virtual Internship
                      </a>
                    </h3>
                    <p className="text-muted-foreground">May 2023 - July 2023</p>
                  </div>
                  <p className="mt-4 text-muted-foreground">
                    Participated in a comprehensive AI/ML training program covering fundamental concepts and practical
                    applications. Completed projects involving data analysis, predictive modeling, and machine learning
                    algorithms. Gained hands-on experience with industry-standard tools and methodologies in artificial
                    intelligence.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Projects Section with improved responsive grid */}
        <section id="projects" className="w-full py-8 md:py-12 lg:py-16">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Projects</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Technical implementations showcasing skills and problem-solving abilities
                </p>
              </div>
            </div>
            <div className="mx-auto max-w-5xl mt-8">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
                {projects.map((project, index) => (
                  <Card
                    key={index}
                    className="h-full border border-border/50 hover:border-primary/30 transition-all duration-300 flex flex-col"
                  >
                    <CardHeader className="bg-primary/5 pb-2">
                      <CardTitle className="text-xl line-clamp-2">
                        <Link
                          href={project.link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="hover:text-primary hover:underline flex items-start gap-2"
                        >
                          <span className="flex-1">{project.title}</span>
                          <ExternalLink className="h-4 w-4 inline flex-shrink-0 mt-1" />
                        </Link>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="py-4 flex-grow">
                      <p className="text-muted-foreground line-clamp-4 sm:line-clamp-none">{project.description}</p>
                      <div className="flex flex-wrap gap-2 mt-4">
                        {project.tags.map((tag, idx) => (
                          <Badge key={idx} variant="secondary">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </CardContent>
                    <CardFooter className="pt-0">
                      <Link href={project.link} target="_blank" rel="noopener noreferrer">
                        <Button variant="outline" size="sm" className="gap-2 touch-target">
                          <Github className="h-4 w-4" />
                          <span className="hidden sm:inline">View on GitHub</span>
                          <span className="sm:hidden">GitHub</span>
                        </Button>
                      </Link>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Skills Section */}
        {/* Skills Section with improved responsive grid */}
        <section id="skills" className="w-full py-8 md:py-12 lg:py-16 bg-muted/40">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Technical Skills</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Core competencies and technical expertise
                </p>
              </div>
            </div>
            <div className="mx-auto max-w-5xl mt-8">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
                {skillCategories.map((category, index) => (
                  <Card
                    key={index}
                    className="h-full border border-border/50 hover:border-primary/30 transition-all duration-300"
                  >
                    <CardHeader className="bg-primary/5 flex flex-row items-center gap-4 pb-2">
                      {category.icon}
                      <CardTitle className="text-base sm:text-lg md:text-xl">{category.title}</CardTitle>
                    </CardHeader>
                    <CardContent className="pt-4 sm:pt-6">
                      <ul className="space-y-2 sm:space-y-3">
                        {category.skills.map((skill, idx) => (
                          <li key={idx} className="flex items-center">
                            <div className="mr-3 h-2 w-2 rounded-full bg-primary"></div>
                            <span className="text-sm sm:text-base">{skill}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Achievements Section */}
        {/* Achievements Section with improved responsive grid */}
        <section id="achievements" className="w-full py-8 md:py-12 lg:py-16">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                  Certifications & Achievements
                </h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Professional development and recognition
                </p>
              </div>
            </div>
            <div className="mx-auto max-w-5xl mt-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
                {achievements.map((achievement, index) => (
                  <Card
                    key={index}
                    className="h-full border border-border/50 hover:border-primary/30 transition-all duration-300 flex flex-col"
                  >
                    <CardHeader className="bg-primary/5 pb-2">
                      <div className="flex items-start gap-3">
                        {achievement.type === "certification" ? (
                          <Award className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                        ) : (
                          <Code className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                        )}
                        <div>
                          <CardTitle className="text-base sm:text-lg md:text-xl line-clamp-2">
                            <Link
                              href={achievement.link}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="hover:text-primary hover:underline flex items-start gap-2"
                            >
                              <span className="flex-1">{achievement.title}</span>
                              <ExternalLink className="h-4 w-4 inline flex-shrink-0 mt-1" />
                            </Link>
                          </CardTitle>
                          {achievement.date && <p className="text-sm text-muted-foreground">{achievement.date}</p>}
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="py-4 flex-grow">
                      <p className="text-muted-foreground text-sm sm:text-base line-clamp-3 sm:line-clamp-none">
                        {achievement.description}
                      </p>
                      {achievement.organization && (
                        <p className="text-sm text-muted-foreground mt-2">
                          <span className="font-medium">Organization:</span> {achievement.organization}
                        </p>
                      )}
                    </CardContent>
                    <CardFooter className="pt-0">
                      <Link href={achievement.link} target="_blank" rel="noopener noreferrer">
                        <Button variant="outline" size="sm" className="touch-target">
                          <span className="hidden sm:inline">View Certificate</span>
                          <span className="sm:hidden">View</span>
                        </Button>
                      </Link>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="w-full py-8 md:py-12 bg-primary/5">
          <div className="container px-4 md:px-6">
            <div className="mx-auto max-w-3xl text-center">
              <h2 className="text-3xl font-bold tracking-tighter mb-4">Contact Me</h2>
              <p className="text-lg text-muted-foreground mb-8">
                I'm currently seeking opportunities to apply my technical expertise in a professional environment.
                Whether you're looking for a dedicated team member or have a specific project in mind, I welcome the
                opportunity to discuss potential collaboration.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <a href="mailto:rontalapoojareddy@gmail.com">
                  <Button className="w-full sm:w-auto">
                    <Mail className="mr-2 h-4 w-4" /> Email Me
                  </Button>
                </a>
                <Link
                  href="https://drive.google.com/file/d/1Dy-4-AD1j07jP1LdZNlO1TH3OiNw8eIN/view?usp=sharing"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Button variant="outline" className="w-full sm:w-auto">
                    Download Resume
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Scroll to top script */}
      <script
        dangerouslySetInnerHTML={{
          __html: `
    document.addEventListener('DOMContentLoaded', function() {
      const homeLink = document.querySelector('header a[href="/"]');
      if (homeLink) {
        homeLink.addEventListener('click', function(e) {
          if (window.location.pathname === '/') {
            e.preventDefault();
            window.scrollTo({
              top: 0,
              behavior: 'smooth'
            });
          }
        });
      }
    });
    `,
        }}
      />

      {/* Footer */}

      <footer className="w-full border-t py-6">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-16 md:flex-row">
          <p className="text-center text-sm leading-loose text-muted-foreground md:text-left">
            © {new Date().getFullYear()} Pooja Reddy Rontala. All rights reserved.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <ThemeToggle />
            <Link href="https://github.com/rontalapoojareddy" target="_blank" rel="noopener noreferrer">
              <Button size="icon" variant="ghost" className="touch-target">
                <Github className="h-4 w-4" />
                <span className="sr-only">GitHub</span>
              </Button>
            </Link>
            <Link href="https://www.linkedin.com/in/r-pooja-reddy-9b70a1253/" target="_blank" rel="noopener noreferrer">
              <Button size="icon" variant="ghost" className="touch-target">
                <Linkedin className="h-4 w-4" />
                <span className="sr-only">LinkedIn</span>
              </Button>
            </Link>
            <Link href="https://www.hackerrank.com/profile/rontalapoojared1" target="_blank" rel="noopener noreferrer">
              <Button size="icon" variant="ghost" className="touch-target">
                <Code className="h-4 w-4" />
                <span className="sr-only">HackerRank</span>
              </Button>
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
