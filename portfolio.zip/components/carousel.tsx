"use client"

import type React from "react"

import { useState, useEffect, useCallback, type ReactNode } from "react"
import { ChevronLeft, ChevronRight, Pause, Play } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

// Update the CarouselProps interface to include transitionEffect
interface CarouselProps {
  items: ReactNode[]
  interval?: number
  className?: string
  autoplayEnabled?: boolean
  indicators?: boolean
  controls?: boolean
  pauseOnHover?: boolean
  transitionEffect?: "slide" | "fade" | "zoom" // Add this line
}

// Update the Carousel component parameters to include the new prop with a default value
export function Carousel({
  items,
  interval = 10000, // 10 seconds default
  className,
  autoplayEnabled = true,
  indicators = true,
  controls = true,
  pauseOnHover = true,
  transitionEffect = "slide", // Add this line with "slide" as default
}: CarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isPaused, setIsPaused] = useState(false)
  const [touchStart, setTouchStart] = useState<number | null>(null)
  const [touchEnd, setTouchEnd] = useState<number | null>(null)
  const [isTransitioning, setIsTransitioning] = useState(false) // Add this line to track transition state

  // Required minimum swipe distance in pixels
  const minSwipeDistance = 50

  const nextSlide = useCallback(() => {
    setIsTransitioning(true) // Start transition
    setCurrentIndex((prevIndex) => (prevIndex + 1) % items.length)
    // Reset transition state after animation completes
    setTimeout(() => setIsTransitioning(false), 500)
  }, [items.length])

  const prevSlide = useCallback(() => {
    setIsTransitioning(true) // Start transition
    setCurrentIndex((prevIndex) => (prevIndex - 1 + items.length) % items.length)
    // Reset transition state after animation completes
    setTimeout(() => setIsTransitioning(false), 500)
  }, [items.length])

  const goToSlide = useCallback(
    (index: number) => {
      if (index !== currentIndex) {
        setIsTransitioning(true) // Start transition
        setCurrentIndex(index)
        // Reset transition state after animation completes
        setTimeout(() => setIsTransitioning(false), 500)
      }
    },
    [currentIndex],
  )

  const togglePause = useCallback(() => {
    setIsPaused((prev) => !prev)
  }, [])

  // Handle touch events for swipe functionality
  const onTouchStart = (e: React.TouchEvent) => {
    setTouchEnd(null)
    setTouchStart(e.targetTouches[0].clientX)
  }

  const onTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX)
  }

  const onTouchEnd = () => {
    if (!touchStart || !touchEnd) return

    const distance = touchStart - touchEnd
    const isLeftSwipe = distance > minSwipeDistance
    const isRightSwipe = distance < -minSwipeDistance

    if (isLeftSwipe) {
      nextSlide()
    } else if (isRightSwipe) {
      prevSlide()
    }
  }

  // Auto-slide effect
  useEffect(() => {
    if (autoplayEnabled && !isPaused) {
      const slideInterval = setInterval(() => {
        nextSlide()
      }, interval)

      return () => clearInterval(slideInterval)
    }
  }, [autoplayEnabled, isPaused, nextSlide, interval])

  // Update the return statement to handle different transition effects
  return (
    <div
      className={cn("relative w-full overflow-hidden", className)}
      onMouseEnter={pauseOnHover ? () => setIsPaused(true) : undefined}
      onMouseLeave={pauseOnHover ? () => setIsPaused(false) : undefined}
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={onTouchEnd}
      aria-live="polite"
    >
      {/* Slides container with different transition effects */}
      {transitionEffect === "slide" && (
        <div
          className="flex transition-transform duration-500 ease-in-out"
          style={{ transform: `translateX(-${currentIndex * 100}%)` }}
        >
          {items.map((item, index) => (
            <div key={index} className="w-full flex-shrink-0">
              {item}
            </div>
          ))}
        </div>
      )}

      {transitionEffect === "fade" && (
        <div className="relative w-full h-full">
          {items.map((item, index) => (
            <div
              key={index}
              className={cn(
                "absolute top-0 left-0 w-full h-full transition-opacity duration-500 ease-in-out",
                index === currentIndex ? "opacity-100 z-10" : "opacity-0 z-0",
              )}
            >
              {item}
            </div>
          ))}
        </div>
      )}

      {transitionEffect === "zoom" && (
        <div className="relative w-full h-full">
          {items.map((item, index) => (
            <div
              key={index}
              className={cn(
                "absolute top-0 left-0 w-full h-full transition-all duration-500 ease-in-out",
                index === currentIndex ? "opacity-100 z-10 scale-100" : "opacity-0 z-0 scale-110",
              )}
            >
              {item}
            </div>
          ))}
        </div>
      )}

      {/* Controls */}
      {controls && (
        <div className="absolute inset-0 flex items-center justify-between px-4 pointer-events-none">
          <Button
            variant="outline"
            size="icon"
            className="rounded-full bg-background/80 backdrop-blur-sm pointer-events-auto"
            onClick={prevSlide}
            aria-label="Previous slide"
            disabled={isTransitioning}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            className="rounded-full bg-background/80 backdrop-blur-sm pointer-events-auto"
            onClick={nextSlide}
            aria-label="Next slide"
            disabled={isTransitioning}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      )}

      {/* Indicators */}
      {indicators && (
        <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-2">
          {items.map((_, index) => (
            <button
              key={index}
              onClick={() => goToSlide(index)}
              className={cn(
                "w-2.5 h-2.5 rounded-full transition-all",
                index === currentIndex ? "bg-primary w-5" : "bg-primary/30 hover:bg-primary/50",
              )}
              aria-label={`Go to slide ${index + 1}`}
              aria-current={index === currentIndex ? "true" : "false"}
              disabled={isTransitioning}
            />
          ))}
        </div>
      )}

      {/* Pause/Play button */}
      <Button
        variant="outline"
        size="icon"
        className="absolute bottom-4 right-4 rounded-full bg-background/80 backdrop-blur-sm z-10"
        onClick={togglePause}
        aria-label={isPaused ? "Play slideshow" : "Pause slideshow"}
      >
        {isPaused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
      </Button>

      {/* Accessibility announcement for screen readers */}
      <div className="sr-only" aria-live="polite">
        Slide {currentIndex + 1} of {items.length}
      </div>
    </div>
  )
}
