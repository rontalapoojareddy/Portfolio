"use client"

import Link from "next/link"
import { Award, ExternalLink, Code } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Carousel } from "@/components/carousel"

// Define the achievement type
interface Achievement {
  title: string
  description: string
  link: string
  date?: string
  type: "certification" | "award" | "challenge"
  organization?: string
}

// Sample achievement data
const achievements: Achievement[] = [
  {
    title: "Coursera: Digital Marketing Strategy and Planning",
    description:
      "Completed a comprehensive course on digital marketing strategies and planning techniques. Learned about market analysis, campaign development, and performance measurement.",
    link: "https://drive.google.com/file/d/1bwguKL_IVyy5mgq767vUkH7xnBhXaBM5/view?usp=sharing",
    date: "March 2024",
    type: "certification",
    organization: "Coursera",
  },
  {
    title: "Edx: Automated Software Testing by DelftX",
    description:
      "Completed a course on automated software testing techniques and best practices. Learned about test case design, test automation frameworks, and continuous integration.",
    link: "https://drive.google.com/file/d/1rDreRis5OUroU0GhSpzxsxpqsuIQy3xZ/view?usp=sharing",
    type: "certification",
    organization: "Edx",
  },
  {
    title: "NPTEL: Database Management System",
    description:
      "Completed a comprehensive course on database management systems. Learned about database design, SQL, normalization, and transaction management.",
    link: "https://drive.google.com/file/d/187mQtLDJ0tHWttGyzsI9iMW0GgI2T7qB/view?usp=sharing",
    date: "September 2023",
    type: "certification",
    organization: "NPTEL",
  },
  {
    title: "Introduction to Cryptography and Network Security",
    description:
      "Completed a course on cryptography fundamentals and network security principles. Learned about encryption algorithms, security protocols, and cybersecurity best practices.",
    link: "https://drive.google.com/file/d/1lxox1EQ6O7X1sz4ub6bK2bnGw2goE-JN/view?usp=sharing",
    date: "November 2023",
    type: "certification",
  },
  {
    title: "CodeQuest 41 Days Coding Challenge",
    description:
      "Participated in a 41-day coding challenge, solving daily programming problems and algorithms. Improved problem-solving skills and algorithmic thinking.",
    link: "https://drive.google.com/file/d/1nq90nY4MnHzisvHu5vIt_TAfJH8YnOXu/view?usp=sharing",
    type: "challenge",
    organization: "SR University coding club on HackerRank platform",
  },
  {
    title: "Hackathon Participation",
    description:
      "Collaborated with team members to develop innovative solutions to real-world problems within a limited timeframe. Enhanced teamwork, problem-solving, and coding skills.",
    link: "https://drive.google.com/file/d/1ckusFMUmVxW1JzH9wO3P89BnMsu1IvZC/view?usp=sharing",
    type: "challenge",
    organization: "Dept. of Computer Science and Artificial Intelligence, SR University",
  },
  {
    title: "Night Hackathon Participation",
    description:
      "Worked through the night with a team to develop and present a technology solution under tight time constraints. Demonstrated perseverance, creativity, and technical skills.",
    link: "https://drive.google.com/file/d/1lDwNF6Utpf18iUMg7e58myoM4VgNui4r/view?usp=sharing",
    type: "challenge",
    organization: "SR University",
  },
]

export function AchievementCarousel() {
  // Create carousel items from achievements
  const carouselItems = achievements.map((achievement, index) => (
    <Card key={index} className="h-full border-2 hover:border-primary/50 transition-all duration-300 flex flex-col">
      <CardHeader className="bg-primary/5 pb-2">
        <div className="flex items-start gap-3">
          {achievement.type === "certification" ? (
            <Award className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
          ) : (
            <Code className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
          )}
          <div>
            <CardTitle className="text-xl">
              <Link
                href={achievement.link}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-primary hover:underline flex items-center gap-2"
              >
                {achievement.title}
                <ExternalLink className="h-4 w-4 inline" />
              </Link>
            </CardTitle>
            {achievement.date && <p className="text-sm text-muted-foreground">{achievement.date}</p>}
            {achievement.organization && <p className="text-sm text-muted-foreground">{achievement.organization}</p>}
          </div>
        </div>
      </CardHeader>
      <CardContent className="py-4 flex-grow">
        <p className="text-muted-foreground">{achievement.description}</p>
      </CardContent>
      <CardFooter className="pt-0">
        <Link href={achievement.link} target="_blank" rel="noopener noreferrer">
          <Button variant="outline" size="sm">
            View Certificate
          </Button>
        </Link>
      </CardFooter>
    </Card>
  ))

  return (
    <div className="w-full max-w-5xl mx-auto">
      <Carousel
        items={carouselItems}
        interval={10000} // 10 seconds
        className="h-[400px] md:h-[450px] rounded-xl shadow-md"
        transitionEffect="zoom" // Use zoom transition
      />
    </div>
  )
}
