"use client"

import type React from "react"

import { Database, Code, Cpu, Globe, BookOpen, BarChart } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Carousel } from "@/components/carousel"

// Define the skill category type
interface SkillCategory {
  title: string
  icon: React.ReactNode
  skills: string[]
}

// Sample skill categories
const skillCategories: SkillCategory[] = [
  {
    title: "Programming",
    icon: <Code className="h-8 w-8 text-primary" />,
    skills: ["C", "Python"],
  },
  {
    title: "Web Technologies",
    icon: <Globe className="h-8 w-8 text-primary" />,
    skills: ["HTML", "CSS", "JavaScript (Basics)"],
  },
  {
    title: "Frameworks & Tools",
    icon: <Cpu className="h-8 w-8 text-primary" />,
    skills: ["Power BI", "Bootstrap", "Visual Studio Code", "Thonny"],
  },
  {
    title: "Database",
    icon: <Database className="h-8 w-8 text-primary" />,
    skills: ["MySQL"],
  },
  {
    title: "Coursework",
    icon: <BookOpen className="h-8 w-8 text-primary" />,
    skills: ["Data Structures and Algorithms", "Operating Systems", "Database Management Systems", "Computer Networks"],
  },
  {
    title: "Other Skills",
    icon: <BarChart className="h-8 w-8 text-primary" />,
    skills: ["Data Analysis", "Problem Solving", "GitHub", "Team Collaboration"],
  },
]

// Keep the SkillsCarousel component with the default slide transition
export function SkillsCarousel() {
  // Create carousel items from skill categories
  const carouselItems = skillCategories.map((category, index) => (
    <Card key={index} className="h-full border-2 hover:border-primary/50 transition-all duration-300">
      <CardHeader className="bg-primary/5 flex flex-row items-center gap-4 pb-2">
        {category.icon}
        <CardTitle>{category.title}</CardTitle>
      </CardHeader>
      <CardContent className="pt-6">
        <ul className="space-y-3">
          {category.skills.map((skill, idx) => (
            <li key={idx} className="flex items-center">
              <div className="mr-3 h-2 w-2 rounded-full bg-primary"></div>
              <span>{skill}</span>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  ))

  return (
    <div className="w-full max-w-5xl mx-auto">
      <Carousel
        items={carouselItems}
        interval={10000} // 10 seconds
        className="h-[350px] md:h-[400px] rounded-xl shadow-md"
        transitionEffect="slide" // Keep the default slide transition
      />
    </div>
  )
}
