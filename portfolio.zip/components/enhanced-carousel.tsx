"use client"

import type React from "react"

import { useState, useEffect, useCallback, useRef, type ReactNode } from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface EnhancedCarouselProps {
  items: ReactNode[]
  interval?: number
  className?: string
  slideClassName?: string
  effect?: "fade" | "zoom" | "slide"
  showControls?: boolean
  showIndicators?: boolean
  autoplay?: boolean
  loop?: boolean
}

export function EnhancedCarousel({
  items,
  interval = 5000, // 5 seconds default
  className,
  slideClassName,
  effect = "fade",
  showControls = true,
  showIndicators = true,
  autoplay = true,
  loop = true,
}: EnhancedCarouselProps) {
  const [activeIndex, setActiveIndex] = useState(0)
  const [isPaused, setIsPaused] = useState(false)
  const [touchStart, setTouchStart] = useState<number | null>(null)
  const [touchEnd, setTouchEnd] = useState<number | null>(null)
  const carouselRef = useRef<HTMLDivElement>(null)

  // Go to next slide
  const next = useCallback(() => {
    if (!loop && activeIndex === items.length - 1) return
    setActiveIndex((current) => (current + 1) % items.length)
  }, [activeIndex, items.length, loop])

  // Go to previous slide
  const prev = useCallback(() => {
    if (!loop && activeIndex === 0) return
    setActiveIndex((current) => (current === 0 ? items.length - 1 : current - 1))
  }, [activeIndex, items.length, loop])

  // Go to specific slide
  const goTo = useCallback((index: number) => {
    setActiveIndex(index)
  }, [])

  // Handle touch events for mobile swipe
  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStart(e.targetTouches[0].clientX)
  }

  const handleTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX)
  }

  const handleTouchEnd = () => {
    if (!touchStart || !touchEnd) return
    const distance = touchStart - touchEnd
    const isLeftSwipe = distance > 50
    const isRightSwipe = distance < -50

    if (isLeftSwipe) {
      next()
    } else if (isRightSwipe) {
      prev()
    }

    setTouchStart(null)
    setTouchEnd(null)
  }

  // Handle keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowLeft") {
        prev()
      } else if (e.key === "ArrowRight") {
        next()
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [next, prev])

  // Autoplay functionality
  useEffect(() => {
    if (!autoplay || isPaused) return

    const timer = setInterval(() => {
      next()
    }, interval)

    return () => clearInterval(timer)
  }, [autoplay, interval, isPaused, next])

  // Pause on hover/focus
  const handleMouseEnter = () => setIsPaused(true)
  const handleMouseLeave = () => setIsPaused(false)

  // Determine which effect to use
  const getSlideStyles = (index: number) => {
    if (effect === "fade") {
      return cn(
        "absolute top-0 left-0 w-full h-full transition-opacity duration-500 ease-in-out",
        index === activeIndex ? "opacity-100 z-10" : "opacity-0 z-0",
      )
    }

    if (effect === "zoom") {
      return cn(
        "absolute top-0 left-0 w-full h-full transition-all duration-500 ease-in-out",
        index === activeIndex ? "opacity-100 z-10 scale-100" : "opacity-0 z-0 scale-110",
      )
    }

    // Default slide effect
    return cn("flex-shrink-0 w-full h-full transition-transform duration-500 ease-in-out", slideClassName)
  }

  return (
    <div
      ref={carouselRef}
      className={cn("relative overflow-hidden rounded-lg shadow-lg", className)}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      tabIndex={0}
      aria-roledescription="carousel"
      aria-label="Content carousel"
    >
      {/* Slides container */}
      {effect === "slide" ? (
        <div
          className="flex transition-transform duration-500 ease-in-out h-full"
          style={{ transform: `translateX(-${activeIndex * 100}%)` }}
        >
          {items.map((item, index) => (
            <div key={index} className={getSlideStyles(index)}>
              {item}
            </div>
          ))}
        </div>
      ) : (
        <div className="relative h-full">
          {items.map((item, index) => (
            <div key={index} className={getSlideStyles(index)} aria-hidden={index !== activeIndex}>
              {item}
            </div>
          ))}
        </div>
      )}

      {/* Navigation controls */}
      {showControls && items.length > 1 && (
        <>
          <Button
            variant="ghost"
            size="icon"
            className="absolute left-2 top-1/2 -translate-y-1/2 bg-background/80 backdrop-blur-sm rounded-full h-8 w-8 p-1.5 opacity-70 hover:opacity-100 transition-opacity"
            onClick={prev}
            aria-label="Previous slide"
          >
            <ChevronLeft className="h-full w-full" />
          </Button>

          <Button
            variant="ghost"
            size="icon"
            className="absolute right-2 top-1/2 -translate-y-1/2 bg-background/80 backdrop-blur-sm rounded-full h-8 w-8 p-1.5 opacity-70 hover:opacity-100 transition-opacity"
            onClick={next}
            aria-label="Next slide"
          >
            <ChevronRight className="h-full w-full" />
          </Button>
        </>
      )}

      {/* Indicators */}
      {showIndicators && items.length > 1 && (
        <div className="absolute bottom-3 left-0 right-0 flex justify-center gap-1.5 z-10">
          {items.map((_, index) => (
            <button
              key={index}
              className={cn(
                "w-2 h-2 rounded-full transition-all duration-300",
                index === activeIndex ? "bg-primary w-4" : "bg-primary/30 hover:bg-primary/50",
              )}
              onClick={() => goTo(index)}
              aria-label={`Go to slide ${index + 1}`}
              aria-current={index === activeIndex}
            />
          ))}
        </div>
      )}

      {/* Autoplay indicator */}
      {autoplay && (
        <div
          className="absolute bottom-0 left-0 h-0.5 bg-primary/50 transition-all"
          style={{
            width: `${(activeIndex / items.length) * 100}%`,
            transition: isPaused ? "none" : `width ${interval}ms linear`,
          }}
        />
      )}

      {/* Screen reader announcements */}
      <div className="sr-only" aria-live="polite">
        Showing slide {activeIndex + 1} of {items.length}
      </div>
    </div>
  )
}
