"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ExternalLink, Github, Award, Code, Database, Globe, BookOpen, BarChart, Cpu } from "lucide-react"
import Link from "next/link"

// Project type
interface Project {
  title: string
  description: string
  link: string
  tags: string[]
}

// Achievement type
interface Achievement {
  title: string
  description: string
  link: string
  date?: string
  type: "certification" | "award" | "challenge"
  organization?: string
}

// Skill category type
interface SkillCategory {
  title: string
  icon: React.ReactNode
  skills: string[]
}

// Sample projects data
const projects: Project[] = [
  {
    title: "Cybersecurity Enhancement through Malicious URL Detection with ML",
    description: "Developed a system using machine learning algorithms to identify potentially harmful URLs.",
    link: "https://github.com/rontalapoojareddy/MajorProject_Cybersecurity-Enhancement-through-Malicious-URL-Detection-with-ML",
    tags: ["Python", "Machine Learning", "Cybersecurity"],
  },
  {
    title: "Passengers Reservation System",
    description:
      "Implemented a console-based reservation system with features for booking, cancellation, and viewing available seats.",
    link: "https://github.com/rontalapoojareddy/Passenger-reservation-Syestem",
    tags: ["C"],
  },
  {
    title: "Smart Travel Planner",
    description: "Developed a travel planning application that helps users create and manage travel itineraries.",
    link: "https://github.com/rontalapoojareddy/Capstone-Smart-Travel-Planner",
    tags: ["HTML", "CSS", "JavaScript", "Responsive Design"],
  },
  {
    title: "Netflix Home Page Clone",
    description: "Created a responsive clone of the Netflix homepage with attention to detail in layout and styling.",
    link: "https://github.com/rontalapoojareddy/Bharat-Intern-Netflix-home-page",
    tags: ["HTML", "CSS"],
  },
  {
    title: "Temperature Converter",
    description:
      "Developed a web-based temperature converter that allows users to convert between Celsius, Fahrenheit, and Kelvin.",
    link: "https://github.com/rontalapoojareddy/Bharat-Intern-temperature-converter",
    tags: ["HTML", "CSS", "JavaScript"],
  },
]

// Sample achievements data
const achievements: Achievement[] = [
  {
    title: "Coursera: Digital Marketing Strategy",
    description: "Completed a comprehensive course on digital marketing strategies and planning techniques.",
    link: "https://drive.google.com/file/d/1bwguKL_IVyy5mgq767vUkH7xnBhXaBM5/view?usp=sharing",
    date: "March 2024",
    type: "certification",
    organization: "Coursera",
  },
  {
    title: "Edx: Automated Software Testing",
    description: "Learned about test case design, test automation frameworks, and continuous integration.",
    link: "https://drive.google.com/file/d/1rDreRis5OUroU0GhSpzxsxpqsuIQy3xZ/view?usp=sharing",
    type: "certification",
    organization: "Edx",
  },
  {
    title: "NPTEL: Database Management System",
    description: "Learned about database design, SQL, normalization, and transaction management.",
    link: "https://drive.google.com/file/d/187mQtLDJ0tHWttGyzsI9iMW0GgI2T7qB/view?usp=sharing",
    date: "September 2023",
    type: "certification",
    organization: "NPTEL",
  },
  {
    title: "CodeQuest 41 Days Coding Challenge",
    description: "Participated in a 41-day coding challenge, solving daily programming problems and algorithms.",
    link: "https://drive.google.com/file/d/1nq90nY4MnHzisvHu5vIt_TAfJH8YnOXu/view?usp=sharing",
    type: "challenge",
    organization: "SR University coding club",
  },
  {
    title: "Hackathon Participation",
    description: "Collaborated with team members to develop innovative solutions to real-world problems.",
    link: "https://drive.google.com/file/d/1ckusFMUmVxW1JzH9wO3P89BnMsu1IvZC/view?usp=sharing",
    type: "challenge",
    organization: "SR University",
  },
]

// Sample skill categories
const skillCategories: SkillCategory[] = [
  {
    title: "Programming",
    icon: <Code className="h-6 w-6 text-primary" />,
    skills: ["C", "Python"],
  },
  {
    title: "Web Technologies",
    icon: <Globe className="h-6 w-6 text-primary" />,
    skills: ["HTML", "CSS", "JavaScript (Basics)"],
  },
  {
    title: "Frameworks & Tools",
    icon: <Cpu className="h-6 w-6 text-primary" />,
    skills: ["Power BI", "Bootstrap", "Visual Studio Code"],
  },
  {
    title: "Database",
    icon: <Database className="h-6 w-6 text-primary" />,
    skills: ["MySQL"],
  },
  {
    title: "Coursework",
    icon: <BookOpen className="h-6 w-6 text-primary" />,
    skills: ["Data Structures", "Operating Systems", "Database Management", "Computer Networks"],
  },
  {
    title: "Other Skills",
    icon: <BarChart className="h-6 w-6 text-primary" />,
    skills: ["Data Analysis", "Problem Solving", "GitHub", "Team Collaboration"],
  },
]

export function ContentShowcase() {
  const [activeTab, setActiveTab] = useState("projects")

  return (
    <div className="w-full max-w-5xl mx-auto">
      <Tabs defaultValue="projects" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-8">
          <TabsTrigger value="projects">Projects</TabsTrigger>
          <TabsTrigger value="achievements">Achievements</TabsTrigger>
          <TabsTrigger value="skills">Skills</TabsTrigger>
        </TabsList>

        <TabsContent value="projects" className="mt-0">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {projects.map((project, index) => (
              <Card
                key={index}
                className="h-full border border-border/50 hover:border-primary/30 transition-all duration-300 flex flex-col"
              >
                <CardHeader className="bg-primary/5 pb-2">
                  <CardTitle className="text-xl">
                    <Link
                      href={project.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="hover:text-primary hover:underline flex items-center gap-2"
                    >
                      {project.title}
                      <ExternalLink className="h-4 w-4 inline" />
                    </Link>
                  </CardTitle>
                </CardHeader>
                <CardContent className="py-4 flex-grow">
                  <p className="text-muted-foreground">{project.description}</p>
                  <div className="flex flex-wrap gap-2 mt-4">
                    {project.tags.map((tag, idx) => (
                      <Badge key={idx} variant="secondary">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
                <CardFooter className="pt-0">
                  <Link href={project.link} target="_blank" rel="noopener noreferrer">
                    <Button variant="outline" size="sm" className="gap-2">
                      <Github className="h-4 w-4" />
                      View on GitHub
                    </Button>
                  </Link>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="achievements" className="mt-0">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {achievements.map((achievement, index) => (
              <Card
                key={index}
                className="h-full border border-border/50 hover:border-primary/30 transition-all duration-300 flex flex-col"
              >
                <CardHeader className="bg-primary/5 pb-2">
                  <div className="flex items-start gap-3">
                    {achievement.type === "certification" ? (
                      <Award className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                    ) : (
                      <Code className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                    )}
                    <div>
                      <CardTitle className="text-xl">
                        <Link
                          href={achievement.link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="hover:text-primary hover:underline flex items-center gap-2"
                        >
                          {achievement.title}
                          <ExternalLink className="h-4 w-4 inline" />
                        </Link>
                      </CardTitle>
                      {achievement.date && <p className="text-sm text-muted-foreground">{achievement.date}</p>}
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="py-4 flex-grow">
                  <p className="text-muted-foreground">{achievement.description}</p>
                  {achievement.organization && (
                    <p className="text-sm text-muted-foreground mt-2">
                      <span className="font-medium">Organization:</span> {achievement.organization}
                    </p>
                  )}
                </CardContent>
                <CardFooter className="pt-0">
                  <Link href={achievement.link} target="_blank" rel="noopener noreferrer">
                    <Button variant="outline" size="sm">
                      View Certificate
                    </Button>
                  </Link>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="skills" className="mt-0">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {skillCategories.map((category, index) => (
              <Card
                key={index}
                className="h-full border border-border/50 hover:border-primary/30 transition-all duration-300"
              >
                <CardHeader className="bg-primary/5 flex flex-row items-center gap-4 pb-2">
                  {category.icon}
                  <CardTitle>{category.title}</CardTitle>
                </CardHeader>
                <CardContent className="pt-6">
                  <ul className="space-y-3">
                    {category.skills.map((skill, idx) => (
                      <li key={idx} className="flex items-center">
                        <div className="mr-3 h-2 w-2 rounded-full bg-primary"></div>
                        <span>{skill}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
