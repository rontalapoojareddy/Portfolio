"use client"

import Link from "next/link"
import { ExternalLink, Github } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Carousel } from "@/components/carousel"

// Define the project type
interface Project {
  title: string
  description: string
  shortDescription: string
  link: string
  tags: string[]
  image?: string
}

// Sample project data
const projects: Project[] = [
  {
    title: "Cybersecurity Enhancement through Malicious URL Detection with ML",
    shortDescription: "Machine learning approach to detect malicious URLs.",
    description:
      "Developed a system that uses machine learning algorithms to identify potentially harmful URLs. Implemented feature extraction techniques and trained models to classify URLs as malicious or benign.",
    link: "https://github.com/rontalapoojareddy/MajorProject_Cybersecurity-Enhancement-through-Malicious-URL-Detection-with-ML",
    tags: ["Python", "Machine Learning", "Cybersecurity"],
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    title: "Passengers Reservation System",
    shortDescription: "A reservation system built using C language.",
    description:
      "Implemented a console-based reservation system with features for booking, cancellation, and viewing available seats. Used efficient algorithms for data management and user-friendly interfaces.",
    link: "https://github.com/rontalapoojareddy/Passenger-reservation-Syestem",
    tags: ["C"],
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    title: "Smart Travel Planner",
    shortDescription: "A travel planning application with itinerary management.",
    description:
      "Developed a travel planning application that helps users create and manage travel itineraries. Features include destination search, budget tracking, and schedule optimization.",
    link: "https://github.com/rontalapoojareddy/Capstone-Smart-Travel-Planner",
    tags: ["HTML", "CSS", "JavaScript", "Responsive Design"],
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    title: "Netflix Home Page Clone",
    shortDescription: "A recreation of the Netflix homepage using HTML and CSS.",
    description:
      "Created a responsive clone of the Netflix homepage with attention to detail in layout, styling, and interactive elements. Implemented responsive design principles for optimal viewing on different devices.",
    link: "https://github.com/rontalapoojareddy/Bharat-Intern-Netflix-home-page",
    tags: ["HTML", "CSS"],
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    title: "Portfolio Website",
    shortDescription: "Personal portfolio website built with HTML and CSS.",
    description:
      "Designed and developed a personal portfolio website to showcase skills, projects, and achievements. Implemented responsive design and modern UI/UX principles.",
    link: "#",
    tags: ["HTML", "CSS"],
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    title: "Temperature Converter",
    shortDescription: "A tool to convert between temperature units.",
    description:
      "Developed a web-based temperature converter that allows users to convert between Celsius, Fahrenheit, and Kelvin. Implemented input validation and real-time conversion.",
    link: "https://github.com/rontalapoojareddy/Bharat-Intern-temperature-converter",
    tags: ["HTML", "CSS", "JavaScript"],
    image: "/placeholder.svg?height=400&width=600",
  },
]

// Update the ProjectCarousel component to use the fade transition effect
export function ProjectCarousel() {
  // Create carousel items from projects
  const carouselItems = projects.map((project, index) => (
    <Card key={index} className="h-full border-2 hover:border-primary/50 transition-all duration-300 flex flex-col">
      <CardHeader className="bg-primary/5 pb-2">
        <CardTitle className="text-xl">
          <Link
            href={project.link}
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-primary hover:underline flex items-center gap-2"
          >
            {project.title}
            <ExternalLink className="h-4 w-4 inline" />
          </Link>
        </CardTitle>
        <p className="text-muted-foreground text-sm">{project.shortDescription}</p>
      </CardHeader>
      <CardContent className="py-4 flex-grow">
        <p className="text-muted-foreground">{project.description}</p>
        <div className="flex flex-wrap gap-2 mt-4">
          {project.tags.map((tag, idx) => (
            <Badge key={idx} variant="secondary">
              {tag}
            </Badge>
          ))}
        </div>
      </CardContent>
      <CardFooter className="pt-0">
        <Link href={project.link} target="_blank" rel="noopener noreferrer">
          <Button variant="outline" size="sm" className="gap-2">
            <Github className="h-4 w-4" />
            View on GitHub
          </Button>
        </Link>
      </CardFooter>
    </Card>
  ))

  return (
    <div className="w-full max-w-5xl mx-auto">
      <Carousel
        items={carouselItems}
        interval={10000} // 10 seconds
        className="h-[400px] md:h-[450px] rounded-xl shadow-md"
        transitionEffect="fade" // Use fade transition
      />
    </div>
  )
}
