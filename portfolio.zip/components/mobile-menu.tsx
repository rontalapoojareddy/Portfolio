"use client"

import { useState, useEffect } from "react"
import { Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { ThemeToggle } from "@/components/theme-toggle"

export function MobileMenu() {
  const [isOpen, setIsOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  // Handle scroll events to improve mobile UX
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const toggleMenu = () => {
    setIsOpen(!isOpen)
    // Prevent body scroll when menu is open
    if (!isOpen) {
      document.body.style.overflow = "hidden"
    } else {
      document.body.style.overflow = ""
    }
  }

  const closeMenu = () => {
    setIsOpen(false)
    document.body.style.overflow = ""
  }

  // Close menu on resize to prevent issues when switching from mobile to desktop
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 768 && isOpen) {
        closeMenu()
      }
    }

    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [isOpen])

  return (
    <div className="relative">
      <div className="flex items-center gap-2">
        <ThemeToggle />
        <Button
          variant="ghost"
          size="icon"
          onClick={toggleMenu}
          aria-label="Toggle menu"
          className="p-2 touch-manipulation"
        >
          {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </Button>
      </div>

      {isOpen && (
        <>
          {/* Backdrop with improved touch handling */}
          <div
            className="fixed inset-0 bg-background/80 backdrop-blur-sm z-40"
            onClick={closeMenu}
            aria-hidden="true"
            style={{ touchAction: "none" }}
          />

          {/* Menu with improved accessibility and touch targets */}
          <div className="fixed top-16 left-0 right-0 z-50 bg-background border-b shadow-lg max-h-[80vh] overflow-y-auto">
            <nav className="flex flex-col space-y-1 p-2">
              <a
                href="#"
                className="text-foreground hover:text-primary transition-colors py-4 px-4 rounded-md hover:bg-muted touch-manipulation font-medium"
                onClick={(e) => {
                  e.preventDefault()
                  window.scrollTo({
                    top: 0,
                    behavior: "smooth",
                  })
                  closeMenu()
                }}
              >
                Home
              </a>
              {["about", "education", "experience", "projects", "skills", "achievements", "contact"].map((section) => (
                <a
                  key={section}
                  href={`#${section}`}
                  className="text-foreground hover:text-primary transition-colors py-4 px-4 rounded-md hover:bg-muted touch-manipulation capitalize"
                  onClick={() => {
                    setTimeout(closeMenu, 300)
                  }}
                >
                  {section}
                </a>
              ))}
            </nav>
          </div>
        </>
      )}
    </div>
  )
}
